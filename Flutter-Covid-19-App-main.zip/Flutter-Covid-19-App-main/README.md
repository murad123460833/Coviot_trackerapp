![Group 2](https://user-images.githubusercontent.com/47206155/147916110-d19e051b-3246-4377-a807-a1ff4d4a7e9f.png)
# covid_tracker

I have created this app flutter with Rest API, API is open source. 

Youtube Tutorials: https://youtube.com/playlist?list=PLFyjjoCMAPtzgITDreXNNkSWLKbd1wf51


This app has the following features. 

Track whole world covid states
Show overall states in Pie Chart 
Display countries list with active case 
Filter countries list 
Track covid states countries wise

You are welcome to modify the source code and make it usable according to your own requirements. 
